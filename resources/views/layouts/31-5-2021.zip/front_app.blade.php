<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>Login</title>
        <!-- Favicon -->
       <link rel="stylesheet" href="<?php echo e(asset('resources')); ?>/css/styles.css">
       <link rel="stylesheet" href="<?php echo e(asset('resources')); ?>/css/bootstrap.min.css">
    </head>
    <body>  
        <div class="backgr_color">
        </div>
        <div class="container">
            <header class="row">
                <div class="banner">
                    <img src="<?php echo e(asset('black')); ?>/img/Banner.jpg">
                </div>
            </header>
           
                    @yield('content')
        </div>
        @include('layouts.front_footer')
    </body>
</html>
