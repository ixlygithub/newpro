<?php

namespace App\Http\Controllers\userdashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Test;
use DB;
class QuizController extends Controller
{
     public function index($testid){
        $tests = DB::table("tests")->where("id",$testid)->first();
        // print_r($test);
        // exit();
        return view('Userdashboard/quiz',compact('tests'));
    }
}
