<?php

namespace App\Http\Controllers;

class HTMLController extends Controller
{
   
    public function login_html()
    {
        return view('login_html');
    }
    public function question_html()
    {
        return view('question_html');
    }
    public function content_html()
    {
        return view('content_html');
    }
    public function account_final_html()
    {
        return view('account_final');
    }
    public function quiz_html()
    {
        return view('quiz_html');
    }
    
}
